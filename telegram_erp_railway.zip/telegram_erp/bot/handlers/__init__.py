from bot.handlers import start, orders, work, inventory, qc, transfer, reports

all_routers = [
    start.router,
    orders.router,
    work.router,
    inventory.router,
    qc.router,
    transfer.router,
    reports.router,
]
