from aiogram.fsm.state import State, StatesGroup


class RegistrationStates(StatesGroup):
    waiting_phone = State()
    waiting_name = State()


class OrderStates(StatesGroup):
    waiting_model = State()
    waiting_fabric = State()
    waiting_qty = State()
    waiting_price = State()
    waiting_deadline = State()
    waiting_client = State()
    confirm = State()


class WorkStates(StatesGroup):
    select_order = State()
    enter_qty = State()
    confirm = State()


class InventoryStates(StatesGroup):
    select_item = State()
    enter_item_name = State()
    enter_qty = State()
    enter_unit = State()
    select_order = State()
    confirm = State()


class TransferStates(StatesGroup):
    select_order = State()
    select_recipient = State()
    enter_qty = State()
    confirm = State()


class QCStates(StatesGroup):
    select_order = State()
    enter_accepted = State()
    enter_rejected = State()
    enter_reason = State()
    confirm = State()
