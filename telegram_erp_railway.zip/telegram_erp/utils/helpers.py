import uuid
from datetime import datetime


def generate_order_code() -> str:
    """Generate unique order code like ZK-2026-001."""
    year = datetime.now().year
    uid = uuid.uuid4().hex[:4].upper()
    return f"ZK-{year}-{uid}"


def generate_batch_code() -> str:
    """Generate unique batch/QR code for transfers."""
    return f"BATCH-{uuid.uuid4().hex[:8].upper()}"


def format_money(amount) -> str:
    """Format decimal amount as readable string."""
    return f"{float(amount):,.0f} so'm"


def format_qty(qty: int) -> str:
    return f"{qty:,} dona"


def escape_md(text: str) -> str:
    """Escape MarkdownV2 special characters."""
    special = r"\_*[]()~`>#+-=|{}.!"
    return "".join(f"\\{c}" if c in special else c for c in str(text))


def order_status_label(status: str) -> str:
    labels = {
        "open": "🟡 Ochildi",
        "fabric_assigned": "🧵 Mato ajratildi",
        "cutting": "✂️ Bichuvda",
        "sewing": "🪡 Tikuvda",
        "qc": "🔍 QC tekshiruvida",
        "packing": "📦 Upakovkada",
        "ready": "✅ Tayyor",
        "closed": "🔒 Yopildi",
    }
    return labels.get(status, status)


def role_label(role: str) -> str:
    labels = {
        "admin": "👑 Rahbar",
        "manager": "🗂 Boshqaruvchi",
        "sales": "💼 Savdo",
        "fabric_head": "🧵 Mato rahbari",
        "razdacha_head": "📦 Razdacha rahbari",
        "razdacha_helper": "📋 Razdacha yordamchisi",
        "sewer": "🪡 Tikuvchi",
        "cutter": "✂️ Bichuvchi",
        "naitel": "🧶 Natelchi",
        "ironer": "🔥 Dazmolchi",
        "packer": "📫 Upakovshik",
        "qc": "🔍 OTK",
    }
    return labels.get(role, role)
