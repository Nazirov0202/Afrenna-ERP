from functools import wraps

from aiogram.types import Message

from db.models import UserRole
from services.user_service import UserService


def roles_required(*allowed_roles: UserRole):
    """
    Decorator that checks user role before executing the handler.
    Usage:
        @roles_required(UserRole.ADMIN, UserRole.MANAGER)
        async def my_handler(message: Message, session, ...):
            ...
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(message: Message, *args, **kwargs):
            session = kwargs.get("session")
            if session is None:
                await message.answer("❌ Xatolik: sessiya topilmadi.")
                return

            user = await UserService.get_by_telegram_id(session, message.from_user.id)
            if not user:
                await message.answer(
                    "❌ Siz ro'yxatdan o'tmagansiz.\n/start buyrug'ini yuboring."
                )
                return

            if user.role not in allowed_roles:
                await message.answer("⛔ Bu amalni bajarishga ruxsatingiz yo'q.")
                return

            kwargs["current_user"] = user
            return await func(message, *args, **kwargs)
        return wrapper
    return decorator


ADMIN_ROLES = (UserRole.ADMIN, UserRole.MANAGER)
INVENTORY_ROLES = (UserRole.ADMIN, UserRole.MANAGER, UserRole.FABRIC_HEAD)
QC_ROLES = (UserRole.ADMIN, UserRole.MANAGER, UserRole.QC)
RAZDACHA_ROLES = (UserRole.ADMIN, UserRole.MANAGER,
                  UserRole.RAZDACHA_HEAD, UserRole.RAZDACHA_HELPER)
WORKER_ROLES = (
    UserRole.SEWER, UserRole.CUTTER, UserRole.NAITEL,
    UserRole.IRONER, UserRole.PACKER,
    UserRole.ADMIN, UserRole.MANAGER,
)
