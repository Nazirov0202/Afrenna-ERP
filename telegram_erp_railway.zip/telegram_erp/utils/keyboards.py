from aiogram.types import (
    InlineKeyboardButton, InlineKeyboardMarkup,
    KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder

from db.models import Order, UserRole


# ─── Remove keyboard ──────────────────────────────────────────────────────────

def kb_remove():
    return ReplyKeyboardRemove()


# ─── Phone share ──────────────────────────────────────────────────────────────

def kb_share_phone() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.add(KeyboardButton(text="📱 Raqamni ulashish", request_contact=True))
    return builder.as_markup(resize_keyboard=True, one_time_keyboard=True)


# ─── Role selection (admin use) ───────────────────────────────────────────────

ROLE_LABELS = {
    UserRole.ADMIN: "👑 Rahbar (Admin)",
    UserRole.MANAGER: "🗂 Boshqaruvchi",
    UserRole.SALES: "💼 Savdo bo'limi",
    UserRole.FABRIC_HEAD: "🧵 Mato bo'limi rahbari",
    UserRole.RAZDACHA_HEAD: "📦 Razdacha rahbari",
    UserRole.RAZDACHA_HELPER: "📋 Razdacha yordamchisi",
    UserRole.SEWER: "🪡 Tikuvchi",
    UserRole.CUTTER: "✂️ Bichuvchi",
    UserRole.NAITEL: "🧶 Natelchi",
    UserRole.IRONER: "🔥 Dazmolchi",
    UserRole.PACKER: "📫 Upakovshik",
    UserRole.QC: "🔍 Sifat nazoratchisi (OTK)",
}


def kb_select_role() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for role, label in ROLE_LABELS.items():
        builder.button(text=label, callback_data=f"set_role:{role.value}")
    builder.adjust(2)
    return builder.as_markup()


# ─── Main menus ───────────────────────────────────────────────────────────────

def kb_admin_menu() -> ReplyKeyboardMarkup:
    buttons = [
        ["📋 Zakazlar", "👥 Xodimlar"],
        ["🧵 Ombor", "📊 Hisobotlar"],
        ["⚙️ Sozlamalar"],
    ]
    builder = ReplyKeyboardBuilder()
    for row in buttons:
        builder.row(*[KeyboardButton(text=t) for t in row])
    return builder.as_markup(resize_keyboard=True)


def kb_worker_menu() -> ReplyKeyboardMarkup:
    buttons = [
        ["🟢 Ishni boshlash", "✅ Ishni topshirish"],
        ["💰 Mening balansim", "📈 Kunlik hisobot"],
    ]
    builder = ReplyKeyboardBuilder()
    for row in buttons:
        builder.row(*[KeyboardButton(text=t) for t in row])
    return builder.as_markup(resize_keyboard=True)


def kb_inventory_menu() -> ReplyKeyboardMarkup:
    buttons = [
        ["📥 Mato kirim", "📤 Mato chiqim"],
        ["📦 Qoldiq ko'rish", "📜 Tarix"],
    ]
    builder = ReplyKeyboardBuilder()
    for row in buttons:
        builder.row(*[KeyboardButton(text=t) for t in row])
    return builder.as_markup(resize_keyboard=True)


def kb_qc_menu() -> ReplyKeyboardMarkup:
    buttons = [
        ["🔍 Tekshirish", "✅ Qabul qilish"],
        ["❌ Rad etish", "📊 Hisobot"],
    ]
    builder = ReplyKeyboardBuilder()
    for row in buttons:
        builder.row(*[KeyboardButton(text=t) for t in row])
    return builder.as_markup(resize_keyboard=True)


def kb_razdacha_menu() -> ReplyKeyboardMarkup:
    buttons = [
        ["📦 Topshirish", "✅ Tasdiqlash"],
        ["📊 Hisobot"],
    ]
    builder = ReplyKeyboardBuilder()
    for row in buttons:
        builder.row(*[KeyboardButton(text=t) for t in row])
    return builder.as_markup(resize_keyboard=True)


def menu_by_role(role: UserRole) -> ReplyKeyboardMarkup:
    """Return the correct main menu keyboard for a given role."""
    if role in (UserRole.ADMIN, UserRole.MANAGER, UserRole.SALES):
        return kb_admin_menu()
    elif role in (UserRole.FABRIC_HEAD,):
        return kb_inventory_menu()
    elif role in (UserRole.RAZDACHA_HEAD, UserRole.RAZDACHA_HELPER):
        return kb_razdacha_menu()
    elif role == UserRole.QC:
        return kb_qc_menu()
    else:
        return kb_worker_menu()


# ─── Order list ───────────────────────────────────────────────────────────────

def kb_orders_list(orders: list[Order], prefix: str = "order") -> InlineKeyboardMarkup:
    """Inline list of open orders for selection."""
    builder = InlineKeyboardBuilder()
    for order in orders:
        builder.button(
            text=f"📋 {order.order_code} — {order.model_name} ({order.remaining_qty} dona qolgan)",
            callback_data=f"{prefix}:{order.id}",
        )
    builder.button(text="🔙 Bekor qilish", callback_data="cancel")
    builder.adjust(1)
    return builder.as_markup()


# ─── Confirm / Cancel ─────────────────────────────────────────────────────────

def kb_confirm_cancel() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Tasdiqlash", callback_data="confirm")
    builder.button(text="❌ Bekor qilish", callback_data="cancel")
    builder.adjust(2)
    return builder.as_markup()


def kb_yes_no() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Ha", callback_data="yes")
    builder.button(text="❌ Yo'q", callback_data="no")
    builder.adjust(2)
    return builder.as_markup()


# ─── Transfer confirm (for recipient) ────────────────────────────────────────

def kb_transfer_confirm(transfer_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Qabul qilish", callback_data=f"transfer_accept:{transfer_id}")
    builder.button(text="❌ Rad etish", callback_data=f"transfer_reject:{transfer_id}")
    builder.adjust(2)
    return builder.as_markup()
