from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import Transfer, TransferStatus, User, Order
from utils.helpers import generate_batch_code


class TransferService:

    @staticmethod
    async def create(
        session: AsyncSession,
        order: Order,
        from_user: User,
        to_user: User,
        qty: int,
    ) -> Transfer:
        transfer = Transfer(
            order_id=order.id,
            from_user_id=from_user.id,
            to_user_id=to_user.id,
            qty=qty,
            batch_code=generate_batch_code(),
            status=TransferStatus.PENDING,
        )
        session.add(transfer)
        await session.commit()
        await session.refresh(transfer)
        return transfer

    @staticmethod
    async def get_pending_for_user(
        session: AsyncSession, user: User
    ) -> list[Transfer]:
        result = await session.execute(
            select(Transfer).where(
                Transfer.to_user_id == user.id,
                Transfer.status == TransferStatus.PENDING,
            ).order_by(Transfer.created_at.desc())
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_by_id(
        session: AsyncSession, transfer_id: int
    ) -> Transfer | None:
        return await session.get(Transfer, transfer_id)

    @staticmethod
    async def accept(session: AsyncSession, transfer: Transfer) -> Transfer:
        transfer.status = TransferStatus.ACCEPTED
        transfer.confirmed_at = datetime.now(timezone.utc)
        await session.commit()
        await session.refresh(transfer)
        return transfer

    @staticmethod
    async def reject(session: AsyncSession, transfer: Transfer) -> Transfer:
        transfer.status = TransferStatus.REJECTED
        transfer.confirmed_at = datetime.now(timezone.utc)
        await session.commit()
        await session.refresh(transfer)
        return transfer
