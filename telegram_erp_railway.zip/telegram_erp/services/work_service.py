from sqlalchemy.ext.asyncio import AsyncSession

from db.models import Transaction, TransactionType, User, Order
from services.order_service import OrderService
from services.user_service import UserService


class WorkService:
    """Core service: submit work, calculate balance."""

    @staticmethod
    async def submit_work(
        session: AsyncSession,
        user: User,
        order: Order,
        qty: int,
    ) -> tuple[Transaction, float]:
        """
        Record completed work and update user balance.
        Returns (transaction, earned_amount).
        """
        if qty <= 0:
            raise ValueError("Dona soni 0 dan katta bo'lishi kerak.")
        if qty > order.remaining_qty:
            raise ValueError(
                f"Zakazda faqat {order.remaining_qty} dona qolgan, "
                f"lekin {qty} dona kiritdingiz."
            )

        earned = float(order.price_per_unit) * qty

        # Record transaction
        tx = Transaction(
            user_id=user.id,
            order_id=order.id,
            qty=qty,
            amount=earned,
            type=TransactionType.EARN,
            note=f"Ish topshirildi: {order.order_code}",
        )
        session.add(tx)

        # Update order completed qty
        await OrderService.add_completed_qty(session, order, qty)

        # Update user balance
        await UserService.add_balance(session, user, earned)

        await session.commit()
        await session.refresh(tx)
        return tx, earned

    @staticmethod
    async def get_today_transactions(
        session: AsyncSession, user: User
    ) -> list[Transaction]:
        from sqlalchemy import select, func
        from datetime import date

        today = date.today()
        result = await session.execute(
            select(Transaction)
            .where(
                Transaction.user_id == user.id,
                func.date(Transaction.created_at) == today,
            )
            .order_by(Transaction.created_at.desc())
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_all_transactions(
        session: AsyncSession, user: User
    ) -> list[Transaction]:
        from sqlalchemy import select

        result = await session.execute(
            select(Transaction)
            .where(Transaction.user_id == user.id)
            .order_by(Transaction.created_at.desc())
            .limit(50)
        )
        return list(result.scalars().all())
