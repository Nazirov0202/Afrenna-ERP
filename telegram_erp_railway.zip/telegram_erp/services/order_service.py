from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import Order, OrderStatus
from utils.helpers import generate_order_code


class OrderService:

    @staticmethod
    async def create(
        session: AsyncSession,
        model_name: str,
        fabric_type: str,
        total_qty: int,
        price_per_unit: float,
        created_by_id: int,
        client_name: str | None = None,
        deadline=None,
    ) -> Order:
        order = Order(
            order_code=generate_order_code(),
            model_name=model_name,
            fabric_type=fabric_type,
            total_qty=total_qty,
            price_per_unit=price_per_unit,
            created_by_id=created_by_id,
            client_name=client_name,
            deadline=deadline,
        )
        session.add(order)
        await session.commit()
        await session.refresh(order)
        return order

    @staticmethod
    async def get_by_id(session: AsyncSession, order_id: int) -> Order | None:
        return await session.get(Order, order_id)

    @staticmethod
    async def get_open_orders(session: AsyncSession) -> list[Order]:
        result = await session.execute(
            select(Order).where(
                Order.status.notin_([OrderStatus.CLOSED, OrderStatus.READY])
            ).order_by(Order.created_at.desc())
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_all(session: AsyncSession) -> list[Order]:
        result = await session.execute(
            select(Order).order_by(Order.created_at.desc())
        )
        return list(result.scalars().all())

    @staticmethod
    async def update_status(
        session: AsyncSession, order: Order, status: OrderStatus
    ) -> Order:
        order.status = status
        await session.commit()
        await session.refresh(order)
        return order

    @staticmethod
    async def add_completed_qty(
        session: AsyncSession, order: Order, qty: int
    ) -> Order:
        order.completed_qty = (order.completed_qty or 0) + qty
        # Auto-advance status when all done
        if order.completed_qty >= order.total_qty:
            if order.status == OrderStatus.SEWING:
                order.status = OrderStatus.QC
        await session.commit()
        await session.refresh(order)
        return order
