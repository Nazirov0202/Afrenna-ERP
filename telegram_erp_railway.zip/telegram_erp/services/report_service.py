from datetime import date, datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import Order, OrderStatus, Transaction, TransactionType, User


class ReportService:

    @staticmethod
    async def user_daily_report(
        session: AsyncSession, user: User, target_date: date | None = None
    ) -> dict:
        """Returns today's stats for a single worker."""
        if target_date is None:
            target_date = date.today()

        result = await session.execute(
            select(
                func.coalesce(func.sum(Transaction.qty), 0).label("total_qty"),
                func.coalesce(func.sum(Transaction.amount), 0).label("total_earned"),
                func.count(Transaction.id).label("tx_count"),
            ).where(
                Transaction.user_id == user.id,
                Transaction.type == TransactionType.EARN,
                func.date(Transaction.created_at) == target_date,
            )
        )
        row = result.one()
        return {
            "date": target_date,
            "user": user,
            "total_qty": int(row.total_qty),
            "total_earned": float(row.total_earned),
            "tx_count": int(row.tx_count),
            "balance": float(user.balance or 0),
        }

    @staticmethod
    async def all_workers_daily(
        session: AsyncSession, target_date: date | None = None
    ) -> list[dict]:
        """Returns today's stats for ALL workers — for admin."""
        if target_date is None:
            target_date = date.today()

        result = await session.execute(
            select(
                User.id,
                User.full_name,
                User.role,
                func.coalesce(func.sum(Transaction.qty), 0).label("total_qty"),
                func.coalesce(func.sum(Transaction.amount), 0).label("total_earned"),
            )
            .outerjoin(
                Transaction,
                (Transaction.user_id == User.id)
                & (Transaction.type == TransactionType.EARN)
                & (func.date(Transaction.created_at) == target_date),
            )
            .where(User.is_active == True)
            .group_by(User.id, User.full_name, User.role)
            .order_by(func.sum(Transaction.qty).desc().nullslast())
        )
        rows = result.all()
        return [
            {
                "user_id": r.id,
                "full_name": r.full_name,
                "role": r.role,
                "total_qty": int(r.total_qty),
                "total_earned": float(r.total_earned),
            }
            for r in rows
        ]

    @staticmethod
    async def order_status_report(session: AsyncSession) -> list[dict]:
        """Summary of all active orders."""
        result = await session.execute(
            select(Order)
            .where(Order.status != OrderStatus.CLOSED)
            .order_by(Order.deadline.asc().nullslast())
        )
        orders = result.scalars().all()
        return [
            {
                "order_code": o.order_code,
                "model_name": o.model_name,
                "status": o.status,
                "total_qty": o.total_qty,
                "completed_qty": o.completed_qty,
                "progress": o.progress_percent,
                "deadline": o.deadline,
                "client": o.client_name,
            }
            for o in orders
        ]

    @staticmethod
    async def workers_balance_report(session: AsyncSession) -> list[dict]:
        """Current balance of all workers."""
        result = await session.execute(
            select(User)
            .where(User.is_active == True, User.balance > 0)
            .order_by(User.balance.desc())
        )
        users = result.scalars().all()
        return [
            {
                "full_name": u.full_name,
                "role": u.role,
                "balance": float(u.balance),
            }
            for u in users
        ]
