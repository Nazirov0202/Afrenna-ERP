from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import User, UserRole


class UserService:

    @staticmethod
    async def get_by_telegram_id(session: AsyncSession, telegram_id: int) -> User | None:
        result = await session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def get_by_id(session: AsyncSession, user_id: int) -> User | None:
        return await session.get(User, user_id)

    @staticmethod
    async def create(
        session: AsyncSession,
        telegram_id: int,
        full_name: str,
        phone: str | None = None,
    ) -> User:
        user = User(
            telegram_id=telegram_id,
            full_name=full_name,
            phone=phone,
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return user

    @staticmethod
    async def set_role(
        session: AsyncSession, user: User, role: UserRole
    ) -> User:
        user.role = role
        await session.commit()
        await session.refresh(user)
        return user

    @staticmethod
    async def update_phone(
        session: AsyncSession, user: User, phone: str
    ) -> User:
        user.phone = phone
        await session.commit()
        return user

    @staticmethod
    async def get_all_active(session: AsyncSession) -> list[User]:
        result = await session.execute(
            select(User).where(User.is_active == True).order_by(User.full_name)
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_by_role(session: AsyncSession, role: UserRole) -> list[User]:
        result = await session.execute(
            select(User).where(User.role == role, User.is_active == True)
        )
        return list(result.scalars().all())

    @staticmethod
    async def add_balance(
        session: AsyncSession, user: User, amount: float
    ) -> User:
        user.balance = float(user.balance or 0) + amount
        await session.commit()
        return user
