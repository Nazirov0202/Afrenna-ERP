from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import QCResult, User, Order


class QCService:

    @staticmethod
    async def record_result(
        session: AsyncSession,
        inspector: User,
        order: Order,
        accepted_qty: int,
        rejected_qty: int,
        reject_reason: str | None = None,
    ) -> QCResult:
        result = QCResult(
            order_id=order.id,
            inspector_id=inspector.id,
            accepted_qty=accepted_qty,
            rejected_qty=rejected_qty,
            reject_reason=reject_reason,
        )
        session.add(result)

        # Deduct rejected from completed qty
        if rejected_qty > 0:
            order.completed_qty = max(0, (order.completed_qty or 0) - rejected_qty)

        await session.commit()
        await session.refresh(result)
        return result

    @staticmethod
    async def get_order_results(
        session: AsyncSession, order_id: int
    ) -> list[QCResult]:
        result = await session.execute(
            select(QCResult)
            .where(QCResult.order_id == order_id)
            .order_by(QCResult.created_at.desc())
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_today_results(
        session: AsyncSession, inspector: User
    ) -> list[QCResult]:
        from sqlalchemy import func
        from datetime import date

        today = date.today()
        result = await session.execute(
            select(QCResult)
            .where(
                QCResult.inspector_id == inspector.id,
                func.date(QCResult.created_at) == today,
            )
            .order_by(QCResult.created_at.desc())
        )
        return list(result.scalars().all())
