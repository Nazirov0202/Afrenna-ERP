from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import Inventory, InventoryAction, InventoryLog, User, Order


class InventoryService:

    @staticmethod
    async def get_all(session: AsyncSession) -> list[Inventory]:
        result = await session.execute(
            select(Inventory).order_by(Inventory.item_name)
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_by_id(session: AsyncSession, item_id: int) -> Inventory | None:
        return await session.get(Inventory, item_id)

    @staticmethod
    async def create_item(
        session: AsyncSession, item_name: str, unit: str = "metr"
    ) -> Inventory:
        item = Inventory(item_name=item_name, unit=unit)
        session.add(item)
        await session.commit()
        await session.refresh(item)
        return item

    @staticmethod
    async def add_stock(
        session: AsyncSession,
        item: Inventory,
        qty: float,
        performer: User,
        note: str | None = None,
    ) -> InventoryLog:
        item.qty_on_hand = float(item.qty_on_hand or 0) + qty
        log = InventoryLog(
            inventory_id=item.id,
            action=InventoryAction.IN,
            qty=qty,
            performed_by_id=performer.id,
            note=note,
        )
        session.add(log)
        await session.commit()
        await session.refresh(log)
        return log

    @staticmethod
    async def deduct_stock(
        session: AsyncSession,
        item: Inventory,
        qty: float,
        performer: User,
        order: Order | None = None,
        note: str | None = None,
    ) -> InventoryLog:
        if float(item.qty_on_hand) < qty:
            raise ValueError(
                f"Omborda faqat {item.qty_on_hand} {item.unit} bor, "
                f"lekin {qty} so'raldi."
            )
        item.qty_on_hand = float(item.qty_on_hand) - qty
        log = InventoryLog(
            inventory_id=item.id,
            order_id=order.id if order else None,
            action=InventoryAction.OUT,
            qty=qty,
            performed_by_id=performer.id,
            note=note,
        )
        session.add(log)
        await session.commit()
        await session.refresh(log)
        return log

    @staticmethod
    async def get_logs(
        session: AsyncSession, limit: int = 50
    ) -> list[InventoryLog]:
        result = await session.execute(
            select(InventoryLog)
            .order_by(InventoryLog.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())
